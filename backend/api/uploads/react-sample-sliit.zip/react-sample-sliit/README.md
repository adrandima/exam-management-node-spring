#### Please follow below steps

1. npm install
2. Make sure Monogo DB is up and running
3. npm run build
4. npm start
5. Visit http://localhost:3000
6. After a change in UI or backend make sure application is stopped and repeat step 3 and 4.