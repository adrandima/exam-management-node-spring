'use strict';

import React, {Component} from 'react';

export default class About extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return <div>
            This is the about page
        </div>;
    }
}
